# ADR 0002: Azure CNI over kubenet

## Status
Accepted

## Context
AKS supports two networking plugins: `kubenet` (simpler, pods get IPs from
a separate address space, NAT'd to the VNet) and `azure` CNI (pods get real
routable IPs directly from the VNet subnet).

## Decision
Use Azure CNI (`network_plugin = "azure"` in `terraform/main.tf`).

## Reasoning
- Pods getting real VNet IPs means NSGs, VNet peering, and other
  network-layer controls apply directly to pod traffic — this is the more
  "production-realistic" setup and the better one to learn on, since this
  project explicitly wants to cover cloud networking depth.
- kubenet requires more manual route table management as the cluster grows
  and has more networking gotchas in multi-node setups.

## Trade-off acknowledged
Azure CNI consumes more IP addresses from the VNet address space (one per
pod, not just per node) — this requires more deliberate subnet sizing.
kubenet is more IP-address-efficient and simpler for very small learning
clusters. Given the subnet was sized at `/24` (254 usable IPs) specifically
to accommodate this, it's a non-issue here, but worth knowing why the
subnet isn't smaller.
